package one.digitalinnovation.peopleapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeopleapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
